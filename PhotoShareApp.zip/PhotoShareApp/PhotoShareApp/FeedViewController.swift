//
//  FeedViewController.swift
//  PhotoShareApp
//
//  Created by Günce Özer on 29.08.2022.
//

import UIKit
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth
import FirebaseStorage
import SDWebImage

class FeedViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var postArray = [Post]()
   /* var emailArray = [String]()
    var commentArray = [String]()
    var imageArray = [String]()*/
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        getFirebaseData()
        
    }
    
    func getFirebaseData(){
        
        let firestoreDatabase = Firestore.firestore()
        
        firestoreDatabase.collection("Post").order(by: "date", descending: true).addSnapshotListener { (snapshot , error) in
            if error != nil{
                print(error?.localizedDescription)
            }else{
                if snapshot?.isEmpty != true && snapshot != nil
                {
                    
                    //self.emailArray.removeAll(keepingCapacity: false)
                    //self.commentArray.removeAll(keepingCapacity: false)
                   // self.imageArray.removeAll(keepingCapacity: false)
                    self.postArray.removeAll(keepingCapacity: false)
                    
                    for document in snapshot!.documents{
                        //let documentId = document.documentID
                        
                        if let imageUrl = document.get("imageUrl") as? String{
                            if let email = document.get("email") as? String{
                                if let comment = document.get("comment") as? String{
                                    let post = Post(email: email, comment: comment, imageUrl: imageUrl)
                                    self.postArray.append(post)
                                }
                            }
                        }
                        self.tableView.reloadData()
                        

                            
                    }
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! FeedCell
        cell.emailText.text = postArray[indexPath.row].email
        cell.commentText.text = postArray[indexPath.row].comment
       // cell.postImageView.sd_setImage(with: URL(string: self.postArray[indexPath.row].imageUrl))
        cell.postImageView.sd_setImage(with: URL(string: self.postArray[indexPath.row].imageUrl), completed: nil)
        return cell
        
    }
    
    
    
    
   
   

}
